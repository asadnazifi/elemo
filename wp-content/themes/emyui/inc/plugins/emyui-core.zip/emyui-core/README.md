# emyui-core
 This is emyui core plugin which is required for emyui theme
