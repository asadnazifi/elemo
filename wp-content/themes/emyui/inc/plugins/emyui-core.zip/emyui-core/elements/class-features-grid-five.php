<?php

namespace WPC\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit; // Exit if accessed directly


class Feafive extends Widget_Base{

  public function get_name(){
    return 'feafive';
  }

  public function get_title(){
    return esc_html__( 'Grid Coloumns Section', 'emyui-core' );
  }

  public function get_icon(){
    return 'eicon-archive-posts';
  }

  public function get_categories(){
    return ['emyuielements'];
  }

  protected function register_controls(){
    
    $this->start_controls_section(
      'headingss',
      [
        'label' => esc_html__( 'Headings', 'emyui-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );
    $this->add_control(
        'ti212',
        [
            'label' => esc_html__( 'Show Headings', 'emyui-core' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'label_on' => esc_html__( 'Show', 'your-plugin' ),
            'label_off' => esc_html__( 'Hide', 'your-plugin' ),
            'return_value' => 'yes',
            'default' => 'yes',
        ]
    );
    $this->add_control(
        'ti213',
        [
            'label' => esc_html__( 'Main Title', 'emyui-core' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'condition' => [ 'ti212' => 'yes' ],
            'default' => esc_html__( 'OUR MAIN FEATURES', 'emyui-core' ),
           
        ]
    );
    $this->add_control(
      'ti214',
      [
          'label' => esc_html__( 'Sub Title', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'condition' => [ 'ti212' => 'yes' ],
          'default' => esc_html__( 'Level up your web hosting with these must-haves.', 'emyui-core' ),
         
      ]
  );
 
    $this->end_controls_section();

    $this->start_controls_section(
        'boxesss',
        [
          'label' => esc_html__( 'Features', 'emyui-core' ),
                  'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
      );
      $repeater = new \Elementor\Repeater();

      $repeater->add_control(
          'atba1', [
              'label' => esc_html__( 'Coloumn Title', 'emyui-core' ),
              'type' => \Elementor\Controls_Manager::TEXT,
              'default' => esc_html__( 'Data Safety' , 'emyui-core' ),
          ]
      );
      $repeater->add_control(
          'atba2', [
              'label' => esc_html__( 'Coloumn Description', 'emyui-core' ),
              'type' => \Elementor\Controls_Manager::TEXTAREA,
              'default' => esc_html__( 'Increase your visitors’ confidence with Positive SSL, giving you a secured-site badge to display.' , 'emyui-core' ),
          ]
      );
      $repeater->add_control(
        'atba3', [
            'label' => esc_html__( 'Button Text', 'emyui-core' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => esc_html__( 'Learn more' , 'emyui-core' ),
        ]
    );
    $repeater->add_control(
        'atba4', [
            'label' => esc_html__( 'Button Link', 'emyui-core' ),
            'type' => \Elementor\Controls_Manager::TEXTAREA,
            'default' => esc_html__( '#', 'emyui-core' ),
        ]
    );
    $repeater->add_control(
			'febo',
			[
				'label' => esc_html__( 'First Grid image', 'emyui-core' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			
			]
		);


      $this->add_control(
          'boxfe',
          [
              'label' => esc_html__( 'Boxes', 'emyui-core' ),
              'type' => \Elementor\Controls_Manager::REPEATER,
              'fields' => $repeater->get_controls(),
              'default' => [
                  [
                      'atba1' => esc_html__( 'Data Safety', 'emyui-core' ),
                      'atba2' => esc_html__( 'Increase your visitors’ confidence with Positive SSL, giving you a secured-site badge to display.', 'emyui-core' ),
                      'atba3' => esc_html__( 'Learn More', 'emyui-core' ),
                      'atba4' => esc_html__( '#', 'emyui-core' ),
                  
                  ],
                 
              ],
          ]
      );


          $this->end_controls_section();
        }


  protected function render(){
    $settings = $this->get_settings_for_display();
    ?>


<div class="service-section bg-default-4 pt-15 pb-13 py-lg-25">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-6 col-lg-7 col-md-9">
                            <div class="section-title text-center mb-11 mb-lg-19 px-lg-3">
                                <h4 class="pre-title coodiv-text-12 text-red text-uppercase mb-7"><?php echo esc_html($settings['ti213']); ?></h4>
                                <h2 class="title coodiv-text-4"><?php echo esc_html($settings['ti214']); ?></h2>
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center position-relative coodiv-z-index-1">
                      <?php 
                    if ( $settings['boxfe'] ) {
		
			foreach (  $settings['boxfe'] as $item ) { ?>
		<div class="col-md-6 col-lg-4 mb-9 mb-lg-0" data-aos="fade-right" data-aos-duration="800" data-aos-once="true">
                            <div class="service-card rounded-10 coodiv-hover-shadow-3 d-flex flex-column text-center pt-15 px-9 pb-11 light-mode-texts coodiv-bg-gray-2-opacity-visible h-100">
                                <div class="card-img mb-11">
                                    <img class="w-100" src="<?php echo esc_url($item['febo']['url']); ?>" alt="<?php echo esc_attr(\Elementor\Control_Media::get_image_alt( $item['febo'] )); ?>" />
                                </div>
                                <h3 class="card-title coodiv-text-6 mb-6"><?php echo esc_html($item['atba1']); ?></h3>
                                <p class="coodiv-text-9 mb-11"><?php echo esc_html($item['atba2']); ?></p>
                                <a href="<?php echo esc_html($item['atba4']); ?>" class="coodiv-text-9 btn btn-primary text-white mt-auto"><?php echo esc_html($item['atba3']); ?></a>
                            </div>
                        </div>
	<?php		}
		
		}
    ?>
                        

                      
                    </div>
                </div>
            </div>


    <?php
  }


}
