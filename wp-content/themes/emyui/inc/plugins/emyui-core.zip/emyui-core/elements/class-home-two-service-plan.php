<?php

namespace WPC\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit; // Exit if accessed directly


class Serviceplanone extends Widget_Base{

  public function get_name(){
    return 'serviceplan';
  }

  public function get_title(){
    return esc_html__( 'Service Plan', 'emyui-core' );
  }

  public function get_icon(){
    return 'eicon-archive-posts';
  }

  public function get_categories(){
    return ['emyuielements'];
  }

  protected function register_controls(){
    
    $this->start_controls_section(
      'slide1',
      [
        'label' => esc_html__( 'First Slide', 'emyui-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

	$this->add_control(
		'ico1home2service1',
		[
			'label' => esc_html__( 'Custom HTML', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::CODE,
			'language' => 'html',
			'rows' => 20,
		]
	);
	$this->add_control(
		'1stt1home2service1',
		[
			'label' => esc_html__( 'Main Heading', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'The best web hosting plan', 'emyui-core' ),
		]
	);
	$this->add_control(
		'2ndt1home2service1',
		[
			'label' => esc_html__( 'Sub Heading', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 'emyui-core' ),
		]
	);
	$this->add_control(
		'pricet1home2service1',
		[
			'label' => esc_html__( 'Price Box Title', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'STARTER PLAN', 'emyui-core' ),
		]
	);
	$this->add_control(
		'currency1home2service1',
		[
			'label' => esc_html__( 'currency', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( '$', 'emyui-core' ),
		]
	);
	$this->add_control(
		'boxpricem1home2service1',
		[
			'label' => esc_html__( 'Price', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( '19', 'emyui-core' ),
		]
	);
	$this->add_control(
		'decimals1home2service1',
		[
			'label' => esc_html__( 'Decimals', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( '.99', 'emyui-core' ),
		]
	);
	$this->add_control(
		'periodprice1home2service1',
		[
			'label' => esc_html__( 'period', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'billed yearly', 'emyui-core' ),
		]
	);
	$this->add_control(
		'isoffer1home2service1',
		[
			'label' => esc_html__( 'Is it Offer?', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default' => 'yes',
		]
	);
	$this->add_control(
		'Offerprice1home2service1',
		[
			'label' => esc_html__( 'Offer', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'Save 40%', 'emyui-core' ),
		]
	);
	$this->add_control(
		'button1box1thome2service1',
		[
			'label' => esc_html__( 'Button', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'Try The Plan Now', 'emyui-core' ),
		]
	);
	$this->add_control(
		'button1box1linkhome2service1',
		[
			'label' => esc_html__( 'Button link', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( '#', 'emyui-core' ),
		]
	);
    $repeater = new \Elementor\Repeater();

    $repeater->add_control(
        'listfeatures1thome2service1', [
            'label' => esc_html__( 'Feature', 'emyui-core' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => esc_html__( 'Unlimited Domain Support' , 'emyui-core' ),
            'label_block' => true,
        ]
    );
    $repeater->add_control(
        'listfeatures21home2service1', [
            'label' => esc_html__( 'Is it included?', 'emyui-core' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default' => 'yes',
        ]
    );
    $this->add_control(
        'listfeatures1home2service1',
        [
            'label' => esc_html__( 'Features List', 'emyui-core' ),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'default' => [
                [
                    'list_title' => esc_html__( 'Feature', 'emyui-core' ),
                    'list_content' => esc_html__( 'Unlimited Domain Support', 'emyui-core' ),
                ],
            ],
        ]
    );
     $this->add_control(
         'hasimgfeature1home2service1',
         [
             'label' => esc_html__( 'Has an image?', 'emyui-core' ),
             'type' => \Elementor\Controls_Manager::SWITCHER,
             'return_value' => 'yes',
             'default' => 'yes',
         ]
     );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
                'imdfeature1imghome2service1',
                [
                    'label' => esc_html__( 'image box', 'emyui-core' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                
                ]
            );
            $repeater->add_control(
                'imlinkfeature1home2service1', [
                    'label' => esc_html__( 'Feature', 'emyui-core' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__( 'img link' , 'emyui-core' ),
                    'label_block' => true,
                ]
            );
        $this->add_control(
            'feature1img1home2service1',
            [
                'label' => esc_html__( 'Features img', 'emyui-core' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'list_title' => esc_html__( 'img', 'emyui-core' ),
                    ],
                ],
            ]
        );
        $this->end_controls_section();

//start slide two
    $this->start_controls_section(
      'slide2home2service1',
      [
        'label' => esc_html__( 'Second Slide', 'emyui-core' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
      ]
    );

	$this->add_control(
		'ico2home2service1',
		[
			'label' => esc_html__( 'Custom HTML', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::CODE,
			'language' => 'html',
			'rows' => 20,
		]
	);
	$this->add_control(
		'1stt2home2service1',
		[
			'label' => esc_html__( 'Main Heading', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'Fully managed SSD cloud VPS', 'emyui-core' ),
		]
	);
	$this->add_control(
		'2ndt2home2service1',
		[
			'label' => esc_html__( 'Sub Heading', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 'emyui-core' ),
		]
	);
	$this->add_control(
		'pricet2home2service1',
		[
			'label' => esc_html__( 'Price Box Title', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'STARTER PLAN', 'emyui-core' ),
		]
	);
	$this->add_control(
		'currency2home2service1',
		[
			'label' => esc_html__( 'currency', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( '$', 'emyui-core' ),
		]
	);
	$this->add_control(
		'boxpricem2home2service1',
		[
			'label' => esc_html__( 'Price', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( '19', 'emyui-core' ),
		]
	);
	$this->add_control(
		'decimals2home2service1',
		[
			'label' => esc_html__( 'Decimals', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( '.99', 'emyui-core' ),
		]
	);
	$this->add_control(
		'periodprice2home2service1',
		[
			'label' => esc_html__( 'period', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'billed yearly', 'emyui-core' ),
		]
	);
	$this->add_control(
		'isoffer2home2service1',
		[
			'label' => esc_html__( 'Is it Offer?', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default' => 'yes',
		]
	);
	$this->add_control(
		'Offerprice2home2service1',
		[
			'label' => esc_html__( 'Offer', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'Save 40%', 'emyui-core' ),
		]
	);
	$this->add_control(
		'button1box2thome2service1',
		[
			'label' => esc_html__( 'Button', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( 'Try The Plan Now', 'emyui-core' ),
		]
	);
	$this->add_control(
		'button1box2linkhome2service1',
		[
			'label' => esc_html__( 'Button link', 'emyui-core' ),
			'type' => \Elementor\Controls_Manager::TEXT,
			'default' => esc_html__( '#', 'emyui-core' ),
		]
	);
    $repeater = new \Elementor\Repeater();

    $repeater->add_control(
        'listfeaturest2home2service1', [
            'label' => esc_html__( 'Feature', 'emyui-core' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => esc_html__( 'Unlimited Domain Support' , 'emyui-core' ),
            'label_block' => true,
        ]
    );
    $repeater->add_control(
        'listfeatures22home2service1', [
            'label' => esc_html__( 'Is it included?', 'emyui-core' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
			'return_value' => 'yes',
			'default' => 'yes',
        ]
    );
    $this->add_control(
        'listfeatures2home2service1',
        [
            'label' => esc_html__( 'Features List', 'emyui-core' ),
            'type' => \Elementor\Controls_Manager::REPEATER,
            'fields' => $repeater->get_controls(),
            'default' => [
                [
                    'list_title' => esc_html__( 'Feature', 'emyui-core' ),
                    'list_content' => esc_html__( 'Unlimited Domain Support', 'emyui-core' ),
                ],
            ],
        ]
    );
     $this->add_control(
         'hasimgfeature2home2service1',
         [
             'label' => esc_html__( 'Has an image?', 'emyui-core' ),
             'type' => \Elementor\Controls_Manager::SWITCHER,
             'return_value' => 'yes',
             'default' => 'yes',
         ]
     );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
                'imdfeature2imghome2service1',
                [
                    'label' => esc_html__( 'image box', 'emyui-core' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                
                ]
            );
            $repeater->add_control(
                'imlinkfeature2home2service1', [
                    'label' => esc_html__( 'Feature', 'emyui-core' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__( 'img link' , 'emyui-core' ),
                    'label_block' => true,
                ]
            );
        $this->add_control(
            'feature1img2home2service1',
            [
                'label' => esc_html__( 'Features img', 'emyui-core' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'list_title' => esc_html__( 'img', 'emyui-core' ),
                    ],
                ],
            ]
        );

            $this->end_controls_section();
//start slide three
$this->start_controls_section(
    'slide3home2service1',
    [
      'label' => esc_html__( 'Third Slide', 'emyui-core' ),
              'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
    ]
  );

  $this->add_control(
      'ico3home2service1',
      [
          'label' => esc_html__( 'Custom HTML', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::CODE,
          'language' => 'html',
          'rows' => 20,
      ]
  );
  $this->add_control(
      '1stt3home2service1',
      [
          'label' => esc_html__( 'Main Heading', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( '#1 Managed WordPress hosting', 'emyui-core' ),
      ]
  );
  $this->add_control(
      '2ndt3home2service1',
      [
          'label' => esc_html__( 'Sub Heading', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'pricet3home2service1',
      [
          'label' => esc_html__( 'Price Box Title', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( 'STARTER PLAN', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'currency3home2service1',
      [
          'label' => esc_html__( 'currency', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( '$', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'boxpricem3home2service1',
      [
          'label' => esc_html__( 'Price', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( '19', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'decimals3home2service1',
      [
          'label' => esc_html__( 'Decimals', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( '.99', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'periodprice3home2service1',
      [
          'label' => esc_html__( 'period', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( 'billed yearly', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'isoffer3home2service1',
      [
          'label' => esc_html__( 'Is it Offer?', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::SWITCHER,
          'return_value' => 'yes',
          'default' => 'yes',
      ]
  );
  $this->add_control(
      'Offerprice3home2service1',
      [
          'label' => esc_html__( 'Offer', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( 'Save 40%', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'button1box3thome2service1',
      [
          'label' => esc_html__( 'Button', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( 'Try The Plan Now', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'button1box3linkhome2service1',
      [
          'label' => esc_html__( 'Button link', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( '#', 'emyui-core' ),
      ]
  );
  $repeater = new \Elementor\Repeater();

  $repeater->add_control(
      'listfeaturest3home2service1', [
          'label' => esc_html__( 'Feature', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( 'Unlimited Domain Support' , 'emyui-core' ),
          'label_block' => true,
      ]
  );
  $repeater->add_control(
      'listfeatures23home2service1', [
          'label' => esc_html__( 'Is it included?', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::SWITCHER,
          'return_value' => 'yes',
          'default' => 'yes',
      ]
  );
  $this->add_control(
      'listfeatures3home2service1',
      [
          'label' => esc_html__( 'Features List', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
              [
                  'list_title' => esc_html__( 'Feature', 'emyui-core' ),
                  'list_content' => esc_html__( 'Unlimited Domain Support', 'emyui-core' ),
              ],
          ],
      ]
  );
   $this->add_control(
       'hasimgfeature3home2service1',
       [
           'label' => esc_html__( 'Has an image?', 'emyui-core' ),
           'type' => \Elementor\Controls_Manager::SWITCHER,
           'return_value' => 'yes',
           'default' => 'yes',
       ]
   );

      $repeater = new \Elementor\Repeater();

      $repeater->add_control(
              'imdfeature3imghome2service1',
              [
                  'label' => esc_html__( 'image box', 'emyui-core' ),
                  'type' => \Elementor\Controls_Manager::MEDIA,
                  'default' => [
                      'url' => \Elementor\Utils::get_placeholder_image_src(),
                  ],
              
              ]
          );
          $repeater->add_control(
              'imlinkfeature3home2service1', [
                  'label' => esc_html__( 'Feature', 'emyui-core' ),
                  'type' => \Elementor\Controls_Manager::TEXT,
                  'default' => esc_html__( 'img link' , 'emyui-core' ),
                  'label_block' => true,
              ]
          );
      $this->add_control(
          'feature1img3home2service1',
          [
              'label' => esc_html__( 'Features img', 'emyui-core' ),
              'type' => \Elementor\Controls_Manager::REPEATER,
              'fields' => $repeater->get_controls(),
              'default' => [
                  [
                      'list_title' => esc_html__( 'img', 'emyui-core' ),
                  ],
              ],
          ]
      );
      $this->end_controls_section();
//start slide Fourth
$this->start_controls_section(
    'slide4home2service1',
    [
      'label' => esc_html__( 'Fourth Slide', 'emyui-core' ),
              'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
    ]
  );

  $this->add_control(
      'ico4home2service1',
      [
          'label' => esc_html__( 'Custom HTML', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::CODE,
          'language' => 'html',
          'rows' => 20,
      ]
  );
  $this->add_control(
      '1stt4home2service1',
      [
          'label' => esc_html__( 'Main Heading', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( 'Dedicated AMD EPYC CPU servers', 'emyui-core' ),
      ]
  );
  $this->add_control(
      '2ndt4home2service1',
      [
          'label' => esc_html__( 'Sub Heading', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'pricet4home2service1',
      [
          'label' => esc_html__( 'Price Box Title', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( 'STARTER PLAN', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'currency4home2service1',
      [
          'label' => esc_html__( 'currency', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( '$', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'boxpricem4home2service1',
      [
          'label' => esc_html__( 'Price', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( '19', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'decimals4home2service1',
      [
          'label' => esc_html__( 'Decimals', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( '.99', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'periodprice4home2service1',
      [
          'label' => esc_html__( 'period', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( 'billed yearly', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'isoffer4home2service1',
      [
          'label' => esc_html__( 'Is it Offer?', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::SWITCHER,
          'return_value' => 'yes',
          'default' => 'yes',
      ]
  );
  $this->add_control(
      'Offerprice4home2service1',
      [
          'label' => esc_html__( 'Offer', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( 'Save 40%', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'button1box4thome2service1',
      [
          'label' => esc_html__( 'Button', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( 'Try The Plan Now', 'emyui-core' ),
      ]
  );
  $this->add_control(
      'button1box4linkhome2service1',
      [
          'label' => esc_html__( 'Button link', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( '#', 'emyui-core' ),
      ]
  );
  $repeater = new \Elementor\Repeater();

  $repeater->add_control(
      'listfeaturest4home2service1', [
          'label' => esc_html__( 'Feature', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( 'Unlimited Domain Support' , 'emyui-core' ),
          'label_block' => true,
      ]
  );
  $repeater->add_control(
      'listfeatures24home2service1', [
          'label' => esc_html__( 'Is it included?', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::SWITCHER,
          'return_value' => 'yes',
          'default' => 'yes',
      ]
  );
  $this->add_control(
      'listfeatures4home2service1',
      [
          'label' => esc_html__( 'Features List', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::REPEATER,
          'fields' => $repeater->get_controls(),
          'default' => [
              [
                  'list_title' => esc_html__( 'Feature', 'emyui-core' ),
                  'list_content' => esc_html__( 'Unlimited Domain Support', 'emyui-core' ),
              ],
          ],
      ]
  );
   $this->add_control(
       'hasimgfeature4home2service1',
       [
           'label' => esc_html__( 'Has an image?', 'emyui-core' ),
           'type' => \Elementor\Controls_Manager::SWITCHER,
           'return_value' => 'yes',
           'default' => 'yes',
       ]
   );

      $repeater = new \Elementor\Repeater();

      $repeater->add_control(
              'imdfeature4imghome2service1',
              [
                  'label' => esc_html__( 'image box', 'emyui-core' ),
                  'type' => \Elementor\Controls_Manager::MEDIA,
                  'default' => [
                      'url' => \Elementor\Utils::get_placeholder_image_src(),
                  ],
              
              ]
          );
          $repeater->add_control(
              'imlinkfeature4home2service1', [
                  'label' => esc_html__( 'Feature', 'emyui-core' ),
                  'type' => \Elementor\Controls_Manager::TEXT,
                  'default' => esc_html__( 'img link' , 'emyui-core' ),
                  'label_block' => true,
              ]
          );
      $this->add_control(
          'feature1img4home2service1',
          [
              'label' => esc_html__( 'Features img', 'emyui-core' ),
              'type' => \Elementor\Controls_Manager::REPEATER,
              'fields' => $repeater->get_controls(),
              'default' => [
                  [
                      'list_title' => esc_html__( 'img', 'emyui-core' ),
                  ],
              ],
          ]
      );

          $this->end_controls_section();
        }


  protected function render(){
    $settings = $this->get_settings_for_display();
    ?>


	   <!-- START services plans section -->
	   <div class="sevrices-plans pt-11 pb-7 pt-lg-10 pb-lg-15 bg-default-6 fancy-animation-block-two position-relative">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-7">
                            <div class="main-features-box-container mt-7 mt-lg-0 pl-xl-19">
                                <div class="row align-items-center sevrices-plans-content-nav">
                                    <div class="col-md-6 col-lg-12 aos-init aos-animate" data-aos="fade-left" data-aos-duration="900" data-aos-once="true">
                                        <div class="main-features-box media">
                                            <span class="main-features-box-number"><?php echo _e('1');?></span>
                                            <div class="media-icon circle-sm bg-blue mr-8">
                                                <span class="text-white the-icon"><?php if(empty($settings['ico1home2service1'])){ ?> <i class="feather icon-server"></i> <?php } else{ echo esc_html($settings['ico1home2service1']); } ?> </span>
                                            </div>
                                            <div class="media-body">
                                                <h3 class="title mb-2"><?php echo  esc_html($settings['1stt1home2service1']); ?></h3>
                                                <p class="coodiv-text-9 mb-0"><?php echo  esc_html($settings['2ndt1home2service1']); ?></p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-lg-12 aos-init aos-animate" data-aos="fade-left" data-aos-duration="900" data-aos-once="true">
                                        <div class="main-features-box media">
                                            <span class="main-features-box-number"><?php echo _e('2');?></span>
                                            <div class="media-icon circle-sm bg-info mr-8">
                                                <span class="text-white the-icon"><?php if(empty($settings['ico2home2service1'])){ ?><i class="feather icon-cloud"></i><?php } else{ echo esc_html($settings['ico2home2service1']); } ?></span>
                                            </div>
                                            <div class="media-body">
                                                <h3 class="title mb-2"><?php echo  esc_html($settings['1stt2home2service1']); ?></h3>
                                                <p class="coodiv-text-9 mb-0"><?php echo  esc_html($settings['2ndt2home2service1']); ?></p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-lg-12 aos-init aos-animate" data-aos="fade-left" data-aos-duration="900" data-aos-once="true">
                                        <div class="main-features-box media">
                                            <span class="main-features-box-number"><?php echo _e('3');?></span>
                                            <div class="media-icon circle-sm bg-warning mr-8">
                                                <span class="text-white the-icon"><?php if(empty($settings['ico3home2service1'])){ ?><i class="fab fa-wordpress-simple"></i><?php } else{ echo esc_html($settings['ico3home2service1']); } ?></span>
                                            </div>
                                            <div class="media-body">
                                                <h3 class="title mb-2"><?php echo  esc_html($settings['1stt3home2service1']); ?></h3>
                                                <p class="coodiv-text-9 mb-0"><?php echo  esc_html($settings['2ndt3home2service1']); ?></p>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-lg-12 aos-init aos-animate" data-aos="fade-left" data-aos-duration="900" data-aos-once="true">
                                        <div class="main-features-box media">
                                            <span class="main-features-box-number"><?php echo _e('4');?></span>
                                            <div class="media-icon circle-sm bg-primary mr-8">
                                                <span class="text-white the-icon"><?php if(empty($settings['ico4home2service1'])){ ?><i class="feather icon-pocket"></i><?php } else{ echo esc_html($settings['ico4home2service1']); } ?></span>
                                            </div>
                                            <div class="media-body">
                                                <h3 class="title mb-2"><?php echo  esc_html($settings['1stt4home2service1']); ?></h3>
                                                <p class="coodiv-text-9 mb-0"><?php echo  esc_html($settings['2ndt4home2service1']); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-5">
                            <div class="content-plan-one pr-xl-19 planet-side sevrices-plans-content">
                                <div class="pricing-box-one plan-with-montains">
                                    <i class="feather icon-server box-iconabsolute"></i>
                                    <div class="price-content">
                                        <span class="small-title-header-span">
										<?php echo  esc_html($settings['pricet1home2service1']); ?>
                                           <?php	if ( 'yes' === $settings['isoffer1home2service1'] ) { ?>
                                        <span class="plan-badge"><?php
												echo esc_html($settings['Offerprice1home2service1']);
											}	?></span>
                                        </span>
                                        <div class="d-flex align-items-end mt-11">
                                            <span class="currency mr-2 coodiv-text-6 font-weight-light line-spacing-none text-blackish-blue"><?php echo  esc_html($settings['currency1home2service1']); ?></span>
                                            <h2 class="price-value coodiv-text-2 font-weight-bold line-spacing-none mb-0 dynamic-value text-blackish-blue" data-active="<?php echo  esc_attr($settings['boxpricem1home2service1']); ?>">
                                            <span class="coodiv-text-8 font-weight-light"><?php echo  esc_html($settings['decimals1home2service1']); ?></span>
                                            </h2>
                                        </div>
                                        <span
                                            class="price-bottom-text dynamic-value coodiv-text-11 mt-2 text-blackish-blue coodiv-opacity-7 d-inline-flex"
                                            data-active="<?php echo  esc_attr($settings['periodprice1home2service1']); ?>"
                                        ></span>
                                        <ul class="card-list list-style-check pl-0 mt-5 mt-lg-11"><?php
                                        if ( $settings['listfeatures1home2service1'] ) {
                                			foreach (  $settings['listfeatures1home2service1'] as $item ) {
                                                 if ( 'yes' === $item['listfeatures21home2service1'] ) {
			                                    	 ?><li class="coodiv-text-10 mb-2"><i class="feather icon-check"></i><?php echo esc_html($item['listfeatures1thome2service1']);
                                                                 ?></li><?php } else {
                                                                     ?>
                                                                    <li class="disabled coodiv-text-11"><i class="feather icon-x"></i><?php echo esc_html($item['listfeatures1thome2service1']);
                                                                 ?></li><?php
                                                                 }
                                                            }
                                                        }
                                                        ?>
                                        </ul>
                                    </div>
                                    <a href="<?php echo  esc_url($settings['button1box1linkhome2service1']); ?>" class="btn btn-special-home-plan with-icon coodiv-hover-y px-xl-8 px-lg-4 px-sm-8 px-4 rounded-20 coodiv-text-12 text-uppercase"><?php echo  esc_html($settings['button1box1thome2service1']); ?></a>
                                    <div class="pricing-box-one-payment text-center mt-5">
                                    <?php if ( 'yes' === $settings['hasimgfeature1home2service1'] ) {if ( $settings['feature1img1home2service1'] ) {
                                			foreach (  $settings['feature1img1'] as $item ) {
			                                    	 ?><a href="<?php echo esc_url($settings['imlinkfeature1home2service1']); ?>"><img src="<?php echo esc_url($item['imdfeature1imghome2service1']['url']); ?>" alt="<?php echo esc_attr(\Elementor\Control_Media::get_image_alt( $item['imdfeature1imghome2service1'] )); ?>"/></a>
                                                                    <?php
                                                            }
                                                        }
                                                        }else{} ?>

                                    </div>
                                </div>
                                <div class="pricing-box-one plan-with-montains">
                                    <i class="feather icon-server box-iconabsolute"></i>
                                    <div class="price-content">
                                        <span class="small-title-header-span">
										<?php echo  esc_html($settings['pricet2home2service1']); ?>
                                           <?php	if ( 'yes' === $settings['isoffer2home2service1'] ) { ?>
                                        <span class="plan-badge"><?php
												echo esc_html($settings['Offerprice2home2service1']) ;
											}	?></span>
                                        </span>
                                        <div class="d-flex align-items-end mt-11">
                                            <span class="currency mr-2 coodiv-text-6 font-weight-light line-spacing-none text-blackish-blue"><?php echo  esc_html($settings['currency2home2service1']); ?></span>
                                            <h2 class="price-value coodiv-text-2 font-weight-bold line-spacing-none mb-0 dynamic-value text-blackish-blue" data-active="<?php echo  esc_attr($settings['boxpricem2home2service1']); ?>">
                                            <span class="coodiv-text-8 font-weight-light"><?php echo  esc_html($settings['decimals2home2service1']); ?></span>
                                            </h2>
                                        </div>
                                        <span
                                            class="price-bottom-text dynamic-value coodiv-text-11 mt-2 text-blackish-blue coodiv-opacity-7 d-inline-flex"
                                            data-active="<?php echo  esc_attr($settings['periodprice2home2service1']); ?>"
                                        ></span>
                                        <ul class="card-list list-style-check pl-0 mt-5 mt-lg-11"><?php
                                        if ( $settings['listfeatures2home2service1'] ) {
                                			foreach (  $settings['listfeatures2home2service1'] as $item ) {
                                                 if ( 'yes' === $item['listfeatures22home2service1'] ) {
			                                    	 ?><li class="coodiv-text-10 mb-2"><i class="feather icon-check"></i><?php echo esc_html($item['listfeaturest2home2service1']);
                                                                 ?></li><?php } else {
                                                                     ?>
                                                                    <li class="disabled coodiv-text-11"><i class="feather icon-x"></i><?php echo esc_html($item['listfeaturest2home2service1']);
                                                                 ?></li><?php
                                                                 }
                                                            }
                                                        }
                                                        ?>
                                        </ul>
                                    </div>
                                    <a href="<?php echo  esc_url($settings['button1box2linkhome2service1']); ?>" class="btn btn-special-home-plan with-icon coodiv-hover-y px-xl-8 px-lg-4 px-sm-8 px-4 rounded-20 coodiv-text-12 text-uppercase"><?php echo  esc_html($settings['button1box2thome2service1']); ?></a>
                                    <div class="pricing-box-one-payment text-center mt-5">
                                    <?php if ( 'yes' === $settings['hasimgfeature2home2service1'] ) {if ( $settings['feature1img2home2service1'] ) {
                                			foreach (  $settings['feature1img2home2service1'] as $item ) {
			                                    	 ?><a href="<?php echo esc_url($settings['imlinkfeature2home2service1']); ?>"><img src="<?php echo esc_url($item['imdfeature2imghome2service1']['url']); ?>" alt="<?php echo esc_attr(\Elementor\Control_Media::get_image_alt( $item['imdfeature1img'] )); ?>"/></a>
                                                                    <?php
                                                            }
                                                        }
                                                        }else{} ?>

                                    </div>
                                </div>
                                <div class="pricing-box-one plan-with-montains">
                                    <i class="feather icon-server box-iconabsolute"></i>
                                    <div class="price-content">
                                        <span class="small-title-header-span">
										<?php echo  esc_html($settings['pricet3home2service1']); ?>
                                           <?php	if ( 'yes' === $settings['isoffer3home2service1'] ) { ?>
                                        <span class="plan-badge"><?php
												echo esc_html($settings['Offerprice3home2service1']) ;
											}	?></span>
                                        </span>
                                        <div class="d-flex align-items-end mt-11">
                                            <span class="currency mr-2 coodiv-text-6 font-weight-light line-spacing-none text-blackish-blue"><?php echo  esc_html($settings['currency3home2service1']); ?></span>
                                            <h2 class="price-value coodiv-text-2 font-weight-bold line-spacing-none mb-0 dynamic-value text-blackish-blue" data-active="<?php echo  esc_attr($settings['boxpricem3home2service1']); ?>">
                                            <span class="coodiv-text-8 font-weight-light"><?php echo  esc_html($settings['decimals3home2service1']); ?></span>
                                            </h2>
                                        </div>
                                        <span
                                            class="price-bottom-text dynamic-value coodiv-text-11 mt-2 text-blackish-blue coodiv-opacity-7 d-inline-flex"
                                            data-active="<?php echo  esc_attr($settings['periodprice3home2service1']); ?>"
                                        ></span>
                                        <ul class="card-list list-style-check pl-0 mt-5 mt-lg-11"><?php
                                        if ( $settings['listfeatures3home2service1'] ) {
                                			foreach (  $settings['listfeatures3home2service1'] as $item ) {
                                                 if ( 'yes' === $item['listfeatures23home2service1'] ) {
			                                    	 ?><li class="coodiv-text-10 mb-2"><i class="feather icon-check"></i><?php echo esc_html($item['listfeaturest3home2service1']);
                                                                 ?></li><?php } else {
                                                                     ?>
                                                                    <li class="disabled coodiv-text-11"><i class="feather icon-x"></i><?php echo esc_html($item['listfeaturest3home2service1']);
                                                                 ?></li><?php
                                                                 }
                                                            }
                                                        }
                                                        ?>
                                        </ul>
                                    </div>
                                    <a href="<?php echo  esc_url($settings['button1box3linkhome2service1']); ?>" class="btn btn-special-home-plan with-icon coodiv-hover-y px-xl-8 px-lg-4 px-sm-8 px-4 rounded-20 coodiv-text-12 text-uppercase"><?php echo  esc_html($settings['button1box3thome2service1']); ?></a>
                                    <div class="pricing-box-one-payment text-center mt-5">
                                    <?php if ( 'yes' === $settings['hasimgfeature2home2service1'] ) {if ( $settings['feature1img3home2service1'] ) {
                                			foreach (  $settings['feature1img3home2service1'] as $item ) {
			                                    	 ?><a href="<?php echo esc_url($settings['imlinkfeature3home2service1']); ?>"><img src="<?php echo esc_url($item['imdfeature3imghome2service1']['url']); ?>" alt="<?php echo esc_url(\Elementor\Control_Media::get_image_alt( $item['imdfeature3img'] )); ?>"/></a>
                                                                    <?php
                                                            }
                                                        }
                                                        }else{} ?>

                                    </div>
                                </div>
                                <div class="pricing-box-one plan-with-montains">
                                    <i class="feather icon-server box-iconabsolute"></i>
                                    <div class="price-content">
                                        <span class="small-title-header-span">
										<?php echo  esc_html($settings['pricet4home2service1']); ?>
                                           <?php	if ( 'yes' === $settings['isoffer4home2service1'] ) { ?>
                                        <span class="plan-badge"><?php
												echo esc_html($settings['Offerprice4home2service1']) ;
											}	?></span>
                                        </span>
                                        <div class="d-flex align-items-end mt-11">
                                            <span class="currency mr-2 coodiv-text-6 font-weight-light line-spacing-none text-blackish-blue"><?php echo  esc_html($settings['currency4home2service1']); ?></span>
                                            <h2 class="price-value coodiv-text-2 font-weight-bold line-spacing-none mb-0 dynamic-value text-blackish-blue" data-active="<?php echo  esc_attr($settings['boxpricem4home2service1']); ?>">
                                            <span class="coodiv-text-8 font-weight-light"><?php echo  esc_html($settings['decimals3home2service1']); ?></span>
                                            </h2>
                                        </div>
                                        <span
                                            class="price-bottom-text dynamic-value coodiv-text-11 mt-2 text-blackish-blue coodiv-opacity-7 d-inline-flex"
                                            data-active="<?php echo  esc_attr($settings['periodprice4home2service1']); ?>"
                                        ></span>
                                        <ul class="card-list list-style-check pl-0 mt-5 mt-lg-11"><?php
                                        if ( $settings['listfeatures4home2service1'] ) {
                                			foreach (  $settings['listfeatures4home2service1'] as $item ) {
                                                 if ( 'yes' === $item['listfeatures24home2service1'] ) {
			                                    	 ?><li class="coodiv-text-10 mb-2"><i class="feather icon-check"></i><?php echo esc_html($item['listfeaturest4home2service1']);
                                                                 ?></li><?php } else {
                                                                     ?>
                                                                    <li class="disabled coodiv-text-11"><i class="feather icon-x"></i><?php echo esc_html($item['listfeaturest4home2service1']);
                                                                 ?></li><?php
                                                                 }
                                                            }
                                                        }
                                                        ?>
                                        </ul>
                                    </div>
                                    <a href="<?php echo  esc_url($settings['button1box4linkhome2service1']); ?>" class="btn btn-special-home-plan with-icon coodiv-hover-y px-xl-8 px-lg-4 px-sm-8 px-4 rounded-20 coodiv-text-12 text-uppercase"><?php echo  $settings['button1box4thome2service1']; ?></a>
                                    <div class="pricing-box-one-payment text-center mt-5">
                                    <?php if ( 'yes' === $settings['hasimgfeature2home2service1'] ) {if ( $settings['feature1img3home2service1'] ) {
                                			foreach (  $settings['feature1img3home2service1'] as $item ) {
			                                    	 ?><a href="<?php echo esc_url($settings['imlinkfeature4home2service1']); ?>"><img src="<?php echo esc_url($item['imdfeature4imghome2service1']['url']); ?>" alt="<?php echo esc_attr(\Elementor\Control_Media::get_image_alt( $item['imdfeature4img'] )); ?>"/></a>
                                                                    <?php
                                                            }
                                                        }
                                                        }else{} ?>

                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                
                </div>
            </div>
			<!-- END services plans section -->

<?php if( \Elementor\Plugin::$instance->editor->is_edit_mode() ) { ?>
<script>
if(jQuery(".sevrices-plans").length > 0) {
		$('.sevrices-plans-content').slick({
			slidesToShow: 1,
			slidesToScroll: 1,
			arrows: false,
			dots: true,
			autoplay: true,
			autoplaySpeed: 2000,
			asNavFor: '.sevrices-plans-content-nav'
		});
		$('.sevrices-plans-content-nav').slick({
			slidesToShow: 4,
			slidesToScroll: 1,
			asNavFor: '.sevrices-plans-content',
			dots: false,
			arrows: false,
			centerMode: false,
			focusOnSelect: true
		});
	}
</script>
<?php } ?>

    <?php
  }


}
