<?php

namespace WPC\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit; // Exit if accessed directly


class Blogelement extends Widget_Base{

  public function get_name(){
    return 'blogelement';
  }

  public function get_title(){
    return esc_html__( 'Blog', 'emyui-core' );
  }

  public function get_icon(){
    return 'eicon-archive-posts';
  }

  public function get_categories(){
    return ['emyuielements'];
  }

  protected function register_controls(){
    
    $this->start_controls_section(
        'tab0blogelement',
        [
          'label' => esc_html__( 'Main Tab', 'emyui-core' ),
                  'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
      );
    $this->add_control(
        'titleblogelement',
        [
            'label' => esc_html__( 'Title', 'emyui-core' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => esc_html__( 'Get inspired by the worlds best designers', 'emyui-core' ),
    
        ]
    );
    $this->add_control(
      'subtitleblogelement',
      [
          'label' => esc_html__( 'Subtitle', 'emyui-core' ),
          'type' => \Elementor\Controls_Manager::TEXT,
          'default' => esc_html__( 'OUR LATEST NEWS', 'emyui-core' ),
  
      ]
  );
  $this->add_control(
    'numberblogelement',
    [
      'label' => esc_html__( 'Number Of Posts', 'emyui-core' ),
      'type' => \Elementor\Controls_Manager::NUMBER,
      'min' => 1,
      'step' => 1,
      'default' => 3,
    ]
  );

        
       $this->end_controls_section();
    }
        
  protected function render(){
    $settings = $this->get_settings_for_display();
    ?>
            <div class="blog-section pt-15 pb-14 pt-lg-25 bn-lg-20 position-relative">
                <div class="container">
                    <!-- container -->

                    <!-- START title -->
                    <div class="row justify-content-center">
                        <div class="col-xl-6 col-lg-7 col-md-8">
                            <div class="section-title text-center mb-11 mb-lg-21">
                                <h3 class="sub-badge coodiv-text-12 text-uppercase text-red mb-7"><?php echo esc_html($settings['subtitleblogelement']); ?></h3>
                                <h2 class="title coodiv-text-4 mb-0"><?php echo esc_html($settings['titleblogelement']); ?></h2>
                            </div>
                        </div>
                    </div>
                    <!-- END title -->

   <!-- row -->
   <div class="row justify-content-center">
                        <div class="col-12">
                            <div class="card-blog">


                    <?php
                  
                    // Custom WP query cbew
$npel= $settings['numberblogelement'];
$args_cbew = array(
	'post_type' => array('post'),
	'posts_per_page' => $npel ,
	'order' => 'DESC',

);

$cbew = new \WP_Query( $args_cbew );

if ( $cbew->have_posts() ) {
	while ( $cbew->have_posts() ) {
		$cbew->the_post();
    ?>
 <div class="single-post coodiv-hover-rotate-img">
                                    <div class="case-img overflow-hidden">
                                        <img src="<?php the_post_thumbnail_url(); ?>" alt="<?php echo esc_attr(get_post_meta ( $image_id, '_wp_attachment_image_alt', true )); ?>" class="w-100 rounded-10" />
                                    </div>
                                    <div class="single-post-content position-relative">
                                        <a href="<?php the_permalink(); ?>" class="single-post-category"><?php echo esc_html(get_the_author_meta( 'display_name', false )); ?></a>
                                        <a href="<?php the_permalink(); ?>" class="single-post-title d-block coodiv-text-6 font-weight-bold color-blackish-blue"><?php the_title(); ?></a>
                                    </div>
                                    <div class="single-post-footer justify-content-between">
                                        <a class="comments" href="<?php the_permalink(); ?>"><i class="feather icon-message-circle"></i> <span><?php 

$comcountc = get_comments_number();

if($comcountc == 1){
    echo get_comments_number();  _e( ' Comment', 'emyui' );
}
elseif($comcountc > 1){
    echo get_comments_number();  _e( ' Comments', 'emyui' );
}
elseif($comcountc == 0){
   _e( 'No Comments', 'emyui' );
}

?></span></a>
                                        
                                    </div>
                                </div>
<?php	}
} else {

}

wp_reset_postdata();
?>
                 
                              
                            </div>
                            
                        </div>
                    </div>
                    <!-- END row -->
                </div>
                <!-- END container -->
            </div>

<?php
}
  }

