<?php
 
if (!class_exists('Redux'))
    {
    return;
    }

    $opt_name = "emyuiredux";
    $theme    = wp_get_theme();


    $args = array(
        'opt_name' => $opt_name,
        'display_name' => $theme->get('Name') ,
        'display_version' => $theme->get('Version') ,
        'menu_type' => 'menu',
        'allow_sub_menu' => true,
        'menu_title' => esc_html__('EMYUI Settings', 'emyui-core'),
        'page_title' => esc_html__('ThemeSettings', 'emyui-core') ,
        'google_api_key' => '',
        'google_update_weekly' => false,
        'async_typography' => true,
        'admin_bar' => true,
        'admin_bar_icon' => 'dashicons-admin-settings',
        'admin_bar_priority' => 50,
        'global_variable' => $opt_name,
        'dev_mode' => false,
        'update_notice' => false,
        'customizer' => true,
        'page_priority' => null,
        'page_parent' => 'themes.php',
        'page_permissions' => 'manage_options',
        'menu_icon' => 'dashicons-admin-settings',
        'last_tab' => '',
        'page_icon' => 'icon-themes',
        'page_slug' => 'themeoptions',
        'save_defaults' => true,
        'default_show' => false,
        'default_mark' => '',
        'show_import_export' => true
    );

    Redux::setArgs( $opt_name, $args );

    Redux::setSection($opt_name, array(
        'title' => esc_html__('General Settings', 'emyui') ,
        'id' => esc_html__('general', 'emyui') ,
        'icon' => 'el el-website',
        'fields'  => array(
            array(
                'id'       => 'opt2',
                'type'     => 'media', 
                'url'      => true,
                'title'    => esc_html__('Light Logo URL', 'emyui'),
                'subtitle' => esc_html__('Upload Your Site Logo', 'emyui'),
                'default'  => array(
                    'url'=>'https://emyui.pdthemes.de/wp-content/themes/emyui/image/logo-main-white.png'
                ),
            ),
            array(
                'id'       => 'opt29',
                'type'     => 'media', 
                'url'      => true,
                'title'    => esc_html__('Light Logo URL', 'emyui'),
                'subtitle' => esc_html__('Upload Your Site Logo', 'emyui'),
                'default'  => array(
                    'url'=>'https://emyui.pdthemes.de/wp-content/themes/emyui/image/logo-main-black.png'
                ),
            ),
            array(
                'id'       => 'opt3',
                'type'     => 'switch', 
                'title'    => esc_html__('Preloader', 'emyui'),
                'subtitle' => esc_html__('Enable or disable site preloader', 'emyui'),
                'default'  => true,
            ),
          
        ),
        
       
    ));



     Redux::setSection($opt_name, array(
         'title' => esc_html__('Blog Settings', 'emyui') ,
         'id' => esc_html__('blog', 'emyui') ,
         'icon' => 'el el-website',
         'fields'  => array(
            array(
                'id'       => 'imgb1',
                'type'     => 'media', 
                'url'      => true,
                'title'    => esc_html__('Blog Banner', 'emyui'),
                'default'  => array(
                    'url'=>'https://emyui.pdthemes.de/wp-content/themes/emyui/image/unsplash/56.jpeg'
                ),
            ),
            array(
                'id'       => 'optmine',
                'type'     => 'select',
                'title'    => esc_html__('Blog Layout', 'emyui'), 
                'desc'     => esc_html__('This option will change your blog page design completly', 'emyui'),
                // Must provide key => value pairs for select options
                'options'  => array(
                    '1' => 'First Layput Without Sidebar',
                    '2' => 'First Layput With Sidebar',
                    '3' => 'Second Layout With sidebar',
               
                ),
                'default'  => '2',
            ),
            array(
                'id'       => 'imgb2',
                'type'     => 'media', 
                'url'      => true,
                'title'    => esc_html__('Single Blog Banner', 'emyui'),
                'default'  => array(
                    'url'=>'https://emyui.pdthemes.de/wp-content/themes/emyui/image/unsplash/56.jpeg'
                ),
            ),
			 array(
                'id'       => 'optminee',
                'type'     => 'select',
                'title'    => esc_html__('Single Blog Layout', 'emyui'), 
                'desc'     => esc_html__('This option will change your blog page design completly', 'emyui'),
                // Must provide key => value pairs for select options
                'options'  => array(
                    '1' => 'Without Sidebar',
                    '2' => 'With Sidebar',
                   
               
                ),
                'default'  => '2',
            ),
            
        ),
    ));

    Redux::setSection($opt_name, array(
        'title' => esc_html__('Footer Settings', 'emyui') ,
        'id' => esc_html__('footer', 'emyui') ,
        'icon' => 'el el-website',
        'fields'  => array(
            array(
                'id'    => 'opt-text3',   
                'type'  => 'textarea',
                'title'    => esc_html__('Footer Description', 'emyui'),
                'subtitle' => esc_html__('Put your footer description here', 'emyui'),
                'default'  => esc_html__('Our mission is to make life easier for website developers and their customers. We do it by offering easy to use, fast and reliable web hosting services.', 'emyui'),
            ),
            array(
                'id'    => 'opt-text5',   
                'type'  => 'text',
                'title'    => esc_html__('Footer Email', 'emyui'),
                'subtitle' => esc_html__('Put your footer email here', 'emyui'),
                'default'  => esc_html__('support@coodiv.net', 'emyui'),
                

            ),
            array(
                'id'    => 'opt-text6',   
                'type'  => 'text',
                'title'    => esc_html__('Footer Phone', 'emyui'),
                'subtitle' => esc_html__('Put your phone number here', 'emyui'),
                'default'  => esc_html__('+123-456-6788-99', 'emyui'),

            ),
            array(
                'id'    => 'opt-text66',   
                'type'  => 'text',
                'title'    => esc_html__('Second Coloumn Title', 'emyui'),
                'subtitle' => esc_html__('Put your phone number here', 'emyui'),
                'default'  => esc_html__('Hosting', 'emyui'),

            ),
          
                array(
                    'id'    => 'opt-text77',   
                    'type'  => 'text',
                    'title'    => esc_html__('Third Coloumn Title', 'emyui'),
                    'subtitle' => esc_html__('Put your phone number here', 'emyui'),
                    'default'  => esc_html__('Domain', 'emyui'),
    
                ),
               
                    array(
                        'id'    => 'opt-text88',   
                        'type'  => 'text',
                        'title'    => esc_html__('Fourth Coloumn Title', 'emyui'),
                        'subtitle' => esc_html__('Put your phone number here', 'emyui'),
                        'default'  => esc_html__('Help', 'emyui'),
        
                    ),
                   

            array(
                'id'   => 'info_normal',
                'type' => 'info',
                'desc' => esc_html__('Copyright Area', 'emyui')
            ),
            array(
                'id'    => 'opt-text7',   
                'type'  => 'text',
                'title'    => esc_html__('Copyright Text', 'emyui'),
                'subtitle' => esc_html__('Put your copyright text here', 'emyui'),
                'default'  => esc_html__('© 2021 Copyright, All Right Reserved, Made with lots of coffee', 'emyui'),

            ),
            
            array(
                'id'       => 'opt21',
                'type'     => 'media', 
                'url'      => true,
                'title'    => esc_html__('First Badge', 'emyui'),
                'default'  => array(
                    'url'=>'https://emyui.pdthemes.de/wp-content/themes/emyui/image/payment/visa.png'
                ),
            ),
            array(
                'id'       => 'opt22',
                'type'     => 'media', 
                'url'      => true,
                'title'    => esc_html__('Second Badge', 'emyui'),
                'default'  => array(
                    'url'=>'https://emyui.pdthemes.de/wp-content/themes/emyui/image/payment/mastercard.png'
                ),
            ),
            array(
                'id'       => 'opt23',
                'type'     => 'media', 
                'url'      => true,
                'title'    => esc_html__('Third Badge', 'emyui'),
                'default'  => array(
                    'url'=>'https://emyui.pdthemes.de/wp-content/themes/emyui/image/payment/discover.png'
                ),
            ),
            array(
                'id'       => 'opt24',
                'type'     => 'media', 
                'url'      => true,
                'title'    => esc_html__('Fourth Badge', 'emyui'),
                'default'  => array(
                    'url'=>'https://emyui.pdthemes.de/wp-content/themes/emyui/image/payment/amex.png'
                ),
            ),
            array(
                'id'       => 'opt25',
                'type'     => 'media', 
                'url'      => true,
                'title'    => esc_html__('Fivth Badge', 'emyui'),
                'default'  => array(
                    'url'=>'https://emyui.pdthemes.de/wp-content/themes/emyui/image/payment/jcb.png'
                ),
            ),
            array(
                'id'       => 'opt26',
                'type'     => 'media', 
                'url'      => true,
                'title'    => esc_html__('Sixth Badge', 'emyui'),
                'default'  => array(
                    'url'=>'https://emyui.pdthemes.de/wp-content/themes/emyui/image/payment/maestro.png'
                ),
            ),
            
                
                
         ),
    ));
    Redux::setSection($opt_name, array(
        'title' => esc_html__('Custom Code', 'emyui') ,
        'id' => esc_html__('custom-code', 'emyui') ,
        'icon' => 'el el-website',
        'fields'  => array(
            array(
                'id'    => 'opt71',   
                'type'  => 'textarea',
                'title'    => esc_html__('Header Custom Code', 'emyui'),
                'subtitle' => esc_html__('Put your header custom code here', 'emyui'),
                'desc'     => esc_html__('Note: You must use codes with necessary tags', 'emyui'),
            ),
            array(
                'id'    => 'opt72',   
                'type'  => 'textarea',
                'title'    => esc_html__('Footer Custom Code', 'emyui'),
                'subtitle' => esc_html__('Put your footer custom code here', 'emyui'),
                'desc'     => esc_html__('Note: You must use codes with necessary tags', 'emyui'),
            ),
            
        ),
    ));
 
